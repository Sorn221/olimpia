﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для EditClientWindow.xaml
    /// </summary>
    public partial class EditClientWindow : Window
    {
        client _tempClient;
        public EditClientWindow(client emp)
        {
            InitializeComponent();
            _tempClient = emp;
            PosView.Text = emp.phone_number;
            FioView.Text = emp.fio;
            NumberView.Text = emp.abonement_id.ToString();
        }
        private void EditClient_Click(object sender, RoutedEventArgs e)
        {
            _tempClient.phone_number = PosView.Text;
            _tempClient.fio = FioView.Text;
            _tempClient.abonement_id = (int)Convert.ToInt32(NumberView.Text);

            DatabaseControl.UpdateClient(_tempClient);
            this.Close();
        }
    }
}
