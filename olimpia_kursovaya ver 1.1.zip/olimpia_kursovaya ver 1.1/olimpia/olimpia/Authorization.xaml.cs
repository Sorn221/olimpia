﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Page
    {
        public Authorization()
        {
            InitializeComponent();
        }
        public void authorization_check(object sender, RoutedEventArgs e)
        {
            employees position_check = DatabaseControl.AutorizaitionCheck(login_main.Text, password_main.Password);
            string FIO = position_check.fio;
            if ( position_check.position_emp == "Тренер")
            {
                NavigationService.Navigate(new TrainPage(FIO));
                
            }
            else if(position_check.position_emp == "Администратор")
            {
                NavigationService.Navigate(new AdminPage(FIO));
            }
            else
            {
                
                error_message.Visibility = Visibility.Visible;
                login_main.Text = "";
                password_main.Password = "";
            }

        }

    }
}
