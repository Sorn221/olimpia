﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для TrainingPage.xaml
    /// </summary>
    public partial class TrainingPage : Page
    {
        public TrainingPage()
        {
            InitializeComponent();
            mainDataGridView.ItemsSource = DatabaseControl.GetTrainForView();
        }
        public void RefreshTable()
        {
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetTrainForView();
        }


        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            train p = mainDataGridView.SelectedItem as train;
            if (p != null)
            {
                EditTrainWindow win = new EditTrainWindow(p);
                win.ShowDialog();

            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            train p = mainDataGridView.SelectedItem as train;

            if (p != null)
            {
                DatabaseControl.DelTrain(p);
                RefreshTable();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }

        private void AddTrain_Click(object sender, RoutedEventArgs e)
        {
            AddTrainWindow win = new AddTrainWindow();
            win.ShowDialog();
        }
    }
}
