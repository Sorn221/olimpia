﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для TrainerTrainPage.xaml
    /// </summary>
    public partial class TrainerTrainPage : Page
    {
        public TrainerTrainPage()
        {
            InitializeComponent();
            mainDataGridView.ItemsSource = DatabaseControl.GetTrainForView();
        }
        private void TrainFilter_Click(object sender, RoutedEventArgs e)
        {
            if (TrainFilter.IsChecked == true)
            {
                mainDataGridView.ItemsSource = null;
                mainDataGridView.ItemsSource = DatabaseControl.GetTrainWithFalseForView();
            }
            else
            {
                mainDataGridView.ItemsSource = null;
                mainDataGridView.ItemsSource = DatabaseControl.GetTrainForView();
            }
        }
    }
}
