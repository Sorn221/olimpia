﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для TrainPage.xaml
    /// </summary>
    public partial class TrainPage : Page
    {
        public TrainPage(string _fio)
        {
            InitializeComponent();
            TrainFrame.Content = new MainLogoPage();
            user_fio.Text = _fio;
        }

        private void ExitBut_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Authorization());
        }

        private void ClientPageTrainer_Click(object sender, RoutedEventArgs e)
        {
            TrainFrame.Content = new ClientTrainPage();
        }

        private void trainPageTrainer_Click(object sender, RoutedEventArgs e)
        {
            TrainFrame.Content = new TrainerTrainPage();
        }

    }
}
