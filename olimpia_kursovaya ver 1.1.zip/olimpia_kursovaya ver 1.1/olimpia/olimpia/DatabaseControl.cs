﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;

namespace olimpia
{
    public static class DatabaseControl
    {

        //Методы для сотрудников
        public static employees AutorizaitionCheck(string login, string pass)
        {
            using (DbAppContext ctx = new DbAppContext())
            {

                return ctx.employees.Where(p => p.login == login && p.password_emp == pass).SingleOrDefault();
            }
        }
        
        public static List<employees> GetEmployeesForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.employees.ToList();
            }
        }
        public static List<employees> GetEmpByFilter(string text)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return GetEmployeesForView().Where(c => c.fio.ToLower().Contains(text)).ToList();
            }
        }
        public static List<employees> GetTrainersForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.employees.Where(p => p.position_emp == "Тренер").ToList();
            }
        }

        public static void AddEmp(employees emp)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.employees.Add(emp);
                ctx.SaveChanges();
            }
        }
        public static void DelEmp(employees emp)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.employees.Remove(emp);
                ctx.SaveChanges();
            }
        }

        public static void UpdateEmp(employees emp)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                employees _emp = ctx.employees.FirstOrDefault(p => p.id == emp.id);

                if (_emp == null)
                {
                    return;
                }

                _emp.fio = emp.fio;
                _emp.position_emp =emp.position_emp;

                ctx.SaveChanges();
            }
        }

        //Методы для клиентов

        public static List<client> GetClientByFilter(string text)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return GetClientForView().Where(c => c.fio.ToLower().Contains(text)).ToList();
            }
        }
        public static List<client> GetClientForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.client.ToList();
            }
        }
        public static void AddClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.client.Add(client);
                ctx.SaveChanges();
            }
        }
        public static void DelClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.client.Remove(client);
                ctx.SaveChanges();
            }
        }
        public static void UpdateClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                client _client = ctx.client.FirstOrDefault(p => p.id == client.id);

                if (_client == null)
                {
                    return;
                }

                _client.fio = client.fio;
                _client.phone_number = client.phone_number;
                _client.abonement_id = client.abonement_id;

                ctx.SaveChanges();
            }
        }

        //методы для тренировок
        public static List<train> GetTrainForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.train.Include(p => p.emp_train).Include(p => p.client_train).ToList();
            }
        }
        public static List<train> GetTrainWithFalseForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.train.Where(p => p.status == false).Include(p => p.emp_train).Include(p => p.client_train).ToList();
            }
        }

        public static void DelTrain(train train)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.train.Remove(train);
                ctx.SaveChanges();
            }
        }

        public static void AddTrain(train train)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.train.Add(train);
                ctx.SaveChanges();
            }
        }

        public static void UpdateTrain(train train)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                train _train = ctx.train.Where(p => p.id == train.id).FirstOrDefault();

                if (_train == null)
                {
                    return;
                }

                _train.trainer_id = train.trainer_id;
                _train.client_id = train.client_id;
                _train.train_date = train.train_date;
                _train.price = train.price;
                _train.status = train.status;

                ctx.SaveChanges();
            }
        }
    }

}
