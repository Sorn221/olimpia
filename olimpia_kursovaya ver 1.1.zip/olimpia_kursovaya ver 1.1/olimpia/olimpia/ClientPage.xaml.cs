﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для ClientPage.xaml
    /// </summary>
    public partial class ClientPage : Page
    {
        public ClientPage()
        {
            InitializeComponent();
            mainDataGridView.ItemsSource = DatabaseControl.GetClientForView();
        }

        public void RefreshTable()
        {
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetClientForView();
        }
        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            client p = mainDataGridView.SelectedItem as client;
            if (p != null)
            {
                EditClientWindow win = new EditClientWindow(p);
                win.ShowDialog();

            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }

        }
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            client p = mainDataGridView.SelectedItem as client;

            if (p != null)
            {
                DatabaseControl.DelClient(p);
                RefreshTable();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }

        private void AddClient_Click(object sender, RoutedEventArgs e)
        {
            AddClientWindow win = new AddClientWindow();
            win.ShowDialog();
        }

        private void FilterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetClientByFilter(FilterBox.Text.ToLower());
        }
    }
}
