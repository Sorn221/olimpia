﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для AddTrainWindow.xaml
    /// </summary>
    public partial class AddTrainWindow : Window
    {
        public AddTrainWindow()
        {
            InitializeComponent();
            FioClientView.ItemsSource = DatabaseControl.GetClientForView();
            FioView.ItemsSource = DatabaseControl.GetTrainersForView();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)

        {
            DateTime temp = DateView.SelectedDate.Value;
            temp = temp.AddHours(Convert.ToDouble(HourView.Text));
            temp = temp.AddMinutes(Convert.ToDouble(MinView.Text));
            DatabaseControl.AddTrain(new train
            {
                trainer_id = (int)FioView.SelectedValue,
                client_id = (int)FioClientView.SelectedValue,
                price = (int)Convert.ToInt32(PriceView.Text),
                train_date = temp,
                status = StatusView.IsChecked,
            }) ;
            this.Close();
        }
    }
}
