﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для EditTrainWindow.xaml
    /// </summary>
    public partial class EditTrainWindow : Window
    {
        train _tempTrain;
        public EditTrainWindow(train emp)
        {
            InitializeComponent();

            _tempTrain = emp;
            FioClientView.ItemsSource = DatabaseControl.GetClientForView();
            FioView.ItemsSource = DatabaseControl.GetTrainersForView();
            FioView.SelectedValue = emp.emp_train.id;
            FioClientView.SelectedValue = emp.client_train.id;
            DateView.SelectedDate = emp.train_date;
            DateTime dt = Convert.ToDateTime(emp.train_date);
            HourView.Text = dt.Hour.ToString();
            MinView.Text = dt.Minute.ToString();
            PriceView.Text = emp.price.ToString();
            StatusView.IsChecked = emp.status;

        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            _tempTrain.trainer_id = Convert.ToInt32(FioView.SelectedValue);
            _tempTrain.client_id = Convert.ToInt32(FioClientView.SelectedValue);
            _tempTrain.price = Convert.ToInt32(PriceView.Text);

            DateTime temp = DateView.SelectedDate.Value;
            temp = temp.AddHours(Convert.ToDouble(HourView.Text));
            temp = temp.AddMinutes(Convert.ToDouble(MinView.Text));
            _tempTrain.train_date = temp;
            _tempTrain.status = StatusView.IsChecked;
            DatabaseControl.UpdateTrain(_tempTrain);
            this.Close();
        }
    }
}
