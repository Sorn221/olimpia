﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        employees _tempEmp;
        public EditWindow(employees emp)
        {
            InitializeComponent();
            _tempEmp = emp;
            PosView.Text = emp.position_emp;
            FioView.Text = emp.fio;
        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            _tempEmp.position_emp = PosView.Text;
            _tempEmp.fio = FioView.Text;
            DatabaseControl.UpdateEmp(_tempEmp);
            this.Close();
        }
    }
}
