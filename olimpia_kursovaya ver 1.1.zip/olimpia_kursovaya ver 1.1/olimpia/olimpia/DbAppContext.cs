﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace olimpia
{
    public class DbAppContext : DbContext
    {
        public DbSet<employees> employees { get; set; }
        public DbSet<client> client { get; set; }
        public DbSet<train> train { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Username=postgres;Password=22345621;Database=olimpia_fomin");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<train>().HasOne(p => p.emp_train).WithMany(p => p.train_employees);
            modelBuilder.Entity<train>().HasOne(p => p.client_train).WithMany(p => p.train_client);
        }
    }

}
