﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace olimpia
{
    public class train
    {
        [Key]public int id { get; set; }
        [ForeignKey("emp_train")] public int trainer_id { get; set; }
        [ForeignKey("client_train")] public int client_id { get; set; }
        public int price { get; set; }

        [Column(TypeName = "timestamp")]public DateTime? train_date { get; set; }

        public bool? status { get; set; }

        public employees emp_train { get; set; }

        public client client_train { get; set; }
    }
    
}
