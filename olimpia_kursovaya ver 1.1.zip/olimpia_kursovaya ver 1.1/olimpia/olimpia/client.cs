﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace olimpia
{
    public class client
    {
        [Key]public int id { get; set; }
        public string fio { get; set; }
        public string phone_number { get; set; }
        public int abonement_id { get; set; }

        public List<train> train_client { get; set; }

    }
}
