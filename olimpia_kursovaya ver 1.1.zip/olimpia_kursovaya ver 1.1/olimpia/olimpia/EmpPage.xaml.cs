﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace olimpia
{
    /// <summary>
    /// Логика взаимодействия для EmpPage.xaml
    /// </summary>
    public partial class EmpPage : Page
    {
        public EmpPage()
        {
            InitializeComponent();
            mainDataGridView.ItemsSource = DatabaseControl.GetEmployeesForView();
        }
        public void RefreshTable()
        {
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetEmployeesForView();
        }


        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            employees p = mainDataGridView.SelectedItem as employees;
            if (p != null)
            {
                EditWindow win = new EditWindow(p);
                win.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            employees p = mainDataGridView.SelectedItem as employees;

            if (p != null)
            {
                DatabaseControl.DelEmp(p);
                RefreshTable();
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }

        private void AddEmp_Click(object sender, RoutedEventArgs e)
        {
            AddWindow win = new AddWindow();
            win.ShowDialog();
        }
        private void FilterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            mainDataGridView.ItemsSource = null;
            mainDataGridView.ItemsSource = DatabaseControl.GetEmpByFilter(FilterBox.Text.ToLower());
        }
    }
}
